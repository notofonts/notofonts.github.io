#ifndef OT_LAYOUT_GPOS_CONTEXTPOS_HH
#define OT_LAYOUT_GPOS_CONTEXTPOS_HH

namespace OT {
namespace Layout {
namespace GPOS_impl {

struct ContextPos : Context {};

}
}
}

#endif /* OT_LAYOUT_GPOS_CONTEXTPOS_HH */
